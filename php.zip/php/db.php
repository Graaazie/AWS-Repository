<?php
// db.php
$host = getenv("DB_HOST") ?: "127.0.0.1";
$port = (int)(getenv("DB_PORT") ?: 3306);
$db   = getenv("DB_NAME") ?: "task_system";
$user = getenv("DB_USER") ?: "admin";
$pass = getenv("DB_PASSWORD") ?: "Passw0rd";

$charset = "utf8mb4";

$dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
$options = [
  PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

$pdo = new PDO($dsn, $user, $pass, $options);
